Hunting Zone — FREE SCRIPT (placeholder package)

Replace this zip with your real script files.

Expected path on the website:
  assets/downloads/hunting/script.zip

The Download button on the site points to this file.
