-- انسخ هاد العناصر لـ qb-core/shared/items.lua

['fishingrod'] = {
    ['name'] = 'fishingrod',
    ['label'] = 'صنارة صيد',
    ['weight'] = 1500,
    ['type'] = 'item',
    ['image'] = 'fishingrod.png',
    ['unique'] = false,
    ['useable'] = false,
    ['shouldClose'] = true,
    ['combinable'] = nil,
    ['description'] = 'صنارة قوية للصيد'
},

['fishbait'] = {
    ['name'] = 'fishbait',
    ['label'] = 'طعم سمك',
    ['weight'] = 50,
    ['type'] = 'item',
    ['image'] = 'fishbait.png',
    ['unique'] = false,
    ['useable'] = false,
    ['shouldClose'] = true,
    ['combinable'] = nil,
    ['description'] = 'طعم جذاب للأسماك'
},

['sardine'] = {
    ['name'] = 'sardine',
    ['label'] = 'سردين',
    ['weight'] = 200,
    ['type'] = 'item',
    ['image'] = 'sardine.png',
    ['unique'] = false,
    ['useable'] = false,
    ['shouldClose'] = true,
    ['combinable'] = nil,
    ['description'] = 'سردين طازج'
},

['salmon'] = {
    ['name'] = 'salmon',
    ['label'] = 'سلمون',
    ['weight'] = 1500,
    ['type'] = 'item',
    ['image'] = 'salmon.png',
    ['unique'] = false,
    ['useable'] = false,
    ['shouldClose'] = true,
    ['combinable'] = nil,
    ['description'] = 'سلمون'
},

['tuna'] = {
    ['name'] = 'tuna',
    ['label'] = 'تونة',
    ['weight'] = 2500,
    ['type'] = 'item',
    ['image'] = 'tuna.png',
    ['unique'] = false,
    ['useable'] = false,
    ['shouldClose'] = true,
    ['combinable'] = nil,
    ['description'] = 'تونة'
},

['bass'] = {
    ['name'] = 'bass',
    ['label'] = 'قاروص',
    ['weight'] = 1200,
    ['type'] = 'item',
    ['image'] = 'bass.png',
    ['unique'] = false,
    ['useable'] = false,
    ['shouldClose'] = true,
    ['combinable'] = nil,
    ['description'] = 'قاروص'
},

['rare_fish'] = {
    ['name'] = 'rare_fish',
    ['label'] = 'سمك نادر',
    ['weight'] = 5000,
    ['type'] = 'item',
    ['image'] = 'rare_fish.png',
    ['unique'] = false,
    ['useable'] = false,
    ['shouldClose'] = true,
    ['combinable'] = nil,
    ['description'] = 'سمك نادر جداً'
},

['shark_small'] = {
    ['name'] = 'shark_small',
    ['label'] = 'سمكة قرش صغيرة',
    ['weight'] = 22000,
    ['type'] = 'item',
    ['image'] = 'shark.png',
    ['unique'] = true,
    ['useable'] = false,
    ['shouldClose'] = true,
    ['combinable'] = nil,
    ['description'] = 'سمكة قرش صغيرة نادرة - سعرها 10,000$'
},
