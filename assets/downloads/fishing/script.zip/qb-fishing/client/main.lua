local QBCore = exports['qb-core']:GetCoreObject()
local isFishing = false
local inZone = false
local currentZone = nil
local rodProp = nil
local fishingBlips = {}

local inventoryBlocked = false
local ROD_MODEL = `prop_fishing_rod_01`

local function SetFishingInventoryBlocked(blocked)
    inventoryBlocked = blocked
    if LocalPlayer and LocalPlayer.state then
        LocalPlayer.state:set('inv_busy', blocked, true)
    end
    if blocked then
        pcall(function() exports['qb-inventory']:CloseInventory() end)
        pcall(function() exports['qb-inventory']:closeInventory() end)
    end
end

-- حذف قوي جداً للصنارة
local function ForceDeleteEntity(ent)
    if not ent or ent == 0 then return end
    if not DoesEntityExist(ent) then return end

    -- طلب التحكم من الشبكة
    if NetworkGetEntityIsNetworked(ent) then
        local timeout = 0
        NetworkRequestControlOfEntity(ent)
        while not NetworkHasControlOfEntity(ent) and timeout < 50 do
            NetworkRequestControlOfEntity(ent)
            Wait(10)
            timeout = timeout + 1
        end
    end

    DetachEntity(ent, true, true)
    SetEntityAsMissionEntity(ent, true, true)
    SetEntityCollision(ent, false, false)
    SetEntityVisible(ent, false, false)
    SetEntityAlpha(ent, 0, false)
    FreezeEntityPosition(ent, true)
    SetEntityCoordsNoOffset(ent, 0.0, 0.0, -1000.0, false, false, false)
    DeleteObject(ent)
    DeleteEntity(ent)

    if DoesEntityExist(ent) then
        SetEntityAsNoLongerNeeded(ent)
        DeleteObject(ent)
        DeleteEntity(ent)
    end
end

local function DeleteRod()
    local ped = PlayerPedId()

    -- 1) الـhandle المسجّل
    if rodProp then
        ForceDeleteEntity(rodProp)
        rodProp = nil
    end

    -- 2) أي object معلق على اللاعب
    local attached = GetEntityAttachedTo(ped)
    -- GetEntityAttachedTo يرجع entity اللي اللاعب معلق عليه، مش العكس
    -- ندور على كل objects الموديل
    local handle, obj = FindFirstObject()
    local success = (handle ~= -1)
    local toDelete = {}

    while success do
        if DoesEntityExist(obj) then
            local model = GetEntityModel(obj)
            if model == ROD_MODEL then
                local dist = #(GetEntityCoords(ped) - GetEntityCoords(obj))
                local attachedToPed = IsEntityAttachedToEntity(obj, ped)
                if attachedToPed or dist < 5.0 then
                    toDelete[#toDelete + 1] = obj
                end
            end
        end
        success, obj = FindNextObject(handle)
    end
    EndFindObject(handle)

    for i = 1, #toDelete do
        ForceDeleteEntity(toDelete[i])
    end

    -- 3) مرة أخرى بعد فريم
    CreateThread(function()
        Wait(0)
        local h2, o2 = FindFirstObject()
        local ok = (h2 ~= -1)
        while ok do
            if DoesEntityExist(o2) and GetEntityModel(o2) == ROD_MODEL then
                local d = #(GetEntityCoords(ped) - GetEntityCoords(o2))
                if IsEntityAttachedToEntity(o2, ped) or d < 5.0 then
                    ForceDeleteEntity(o2)
                end
            end
            ok, o2 = FindNextObject(h2)
        end
        EndFindObject(h2)
    end)
end

function IsNearWater()
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)

    if IsEntityInWater(ped) then
        return true
    end

    local distance = Config.WaterDistance or 2.0
    local steps = Config.WaterCheckSteps or 16

    for ring = 1, 2 do
        local radius = distance * (ring / 2)
        for i = 1, steps do
            local angle = (i / steps) * math.pi * 2.0
            local x = coords.x + math.cos(angle) * radius
            local y = coords.y + math.sin(angle) * radius
            local found, waterZ = GetWaterHeightNoWaves(x, y, coords.z + 5.0)
            if found and waterZ and waterZ > -1000.0 then
                if math.abs(waterZ - coords.z) <= (Config.MaxWaterHeightDifference or 3.0) then
                    return true
                end
            end
        end
    end
    return false
end

CreateThread(function()
    while true do
        local wasInZone = inZone
        inZone = IsNearWater()
        currentZone = nil

        if inZone and not wasInZone then
            SendNUIMessage({ action = "enterZone", zone = "Water" })
        elseif not inZone and wasInZone then
            SendNUIMessage({ action = "leaveZone" })
            if isFishing then
                StopFishing()
            else
                local ped = PlayerPedId()
                ClearPedTasksImmediately(ped)
                DeleteRod()
            end
        end
        Wait(200)
    end
end)

CreateThread(function()
    while true do
        if inZone and not isFishing then
            if IsControlJustPressed(0, Config.Keys.fish) then
                TryStartFishing()
                Wait(250)
            else
                Wait(0)
            end
        else
            Wait(100)
        end
    end
end)

CreateThread(function()
    while true do
        if inZone then
            local ped = PlayerPedId()
            local bone = GetPedBoneIndex(ped, 31086)
            local headCoords = GetWorldPositionOfEntityBone(ped, bone)
            if not headCoords or (headCoords.x == 0.0 and headCoords.y == 0.0) then
                headCoords = GetPedBoneCoords(ped, 31086, 0.0, 0.0, 0.0)
            end
            local onScreen, screenX, screenY = World3dToScreen2d(headCoords.x, headCoords.y, headCoords.z + 0.55)
            if onScreen then
                SendNUIMessage({ action = "updatePos", onScreen = true, x = screenX, y = screenY })
            else
                SendNUIMessage({ action = "updatePos", onScreen = false })
            end
            Wait(0)
        else
            Wait(400)
        end
    end
end)

function TryStartFishing()
    if isFishing then return end
    if not inZone then
        QBCore.Functions.Notify('خاصك تكون قريب من الماء (2 متر أو أقل)', 'error')
        return
    end

    QBCore.Functions.TriggerCallback('qb-fishing:server:hasItems', function(has)
        if not has.rod then
            QBCore.Functions.Notify('خاصك تكون عندك صنارة', 'error')
            return
        end
        if not has.bait then
            QBCore.Functions.Notify('خاصك تكون عندك طعم', 'error')
            return
        end
        StartFishing()
    end)
end

function StartFishing()
    isFishing = true
    local ped = PlayerPedId()

    TriggerServerEvent('qb-fishing:server:removeBait')

    RequestAnimDict('mini@tennis')
    RequestAnimDict('amb@world_human_stand_fishing@idle_a')
    while not HasAnimDictLoaded('mini@tennis') or not HasAnimDictLoaded('amb@world_human_stand_fishing@idle_a') do
        Wait(10)
    end

    RequestModel(ROD_MODEL)
    while not HasModelLoaded(ROD_MODEL) do Wait(10) end

    -- امسح أي صنارة قديمة قبل ما نخلق وحدة جديدة
    DeleteRod()
    Wait(50)

    local coords = GetEntityCoords(ped)
    rodProp = CreateObject(ROD_MODEL, coords.x, coords.y, coords.z, true, true, false)
    SetEntityAsMissionEntity(rodProp, true, true)
    SetEntityCollision(rodProp, false, false)

    -- bone 60309 = SKEL_R_Hand | offsets شائعة للصنارة
    AttachEntityToEntity(
        rodProp, ped, GetPedBoneIndex(ped, 60309),
        0.1, 0.05, 0.0,
        80.0, 120.0, 160.0,
        true, true, false, true, 1, true
    )
    SetModelAsNoLongerNeeded(ROD_MODEL)

    DisablePlayerFiring(PlayerId(), true)

    TaskPlayAnim(ped, 'amb@world_human_stand_fishing@idle_a', 'idle_c', 1.0, -1.0, 1800, 11, 0, false, false, false)
    Wait(1800)

    if not isFishing or not inZone then
        StopFishing()
        return
    end

    TaskPlayAnim(ped, 'mini@tennis', 'forehand_ts_md_far', 1.0, -1.0, 1400, 48, 0, false, false, false)
    Wait(1400)

    if not isFishing or not inZone then
        StopFishing()
        return
    end

    TaskPlayAnim(ped, 'amb@world_human_stand_fishing@idle_a', 'idle_c', 1.0, -1.0, -1, 11, 0, false, false, false)

    SendNUIMessage({ action = "startFishing" })

    local waitTime = math.random(Config.MinWait, Config.MaxWait) * 1000
    local startTime = GetGameTimer()

    CreateThread(function()
        while isFishing do
            if not inZone then
                StopFishing()
                break
            end

            local progress = (GetGameTimer() - startTime) / waitTime
            if progress > 1.0 then progress = 1.0 end

            SendNUIMessage({ action = "updateProgress", progress = progress })

            if progress >= 1.0 then
                local fish = GetRandomFish()
                local willEscape = math.random() < Config.EscapeChance

                if willEscape then
                    SendNUIMessage({ action = "fishEscaped" })
                    QBCore.Functions.Notify('السمكة بلعات الطعم وهربات!', 'error')
                    Wait(1500)
                    StopFishing()
                else
                    local requiredKey = (math.random(1, 2) == 1) and 'E' or 'Q'
                    local keyControl = (requiredKey == 'E') and Config.Keys.fish or Config.Keys.q

                    SendNUIMessage({
                        action = "fishBite",
                        fish = fish.name,
                        key = requiredKey,
                        time = Config.BiteTime or 5000
                    })

                    SetFishingInventoryBlocked(true)

                    local success = false
                    local wrongKey = false
                    local timer = GetGameTimer()
                    local timeout = Config.BiteTime or 5000

                    while isFishing and (GetGameTimer() - timer) < timeout do
                        if not inZone then break end

                        if IsControlJustPressed(0, keyControl) then
                            success = true
                            break
                        end
                        local otherControl = (requiredKey == 'E') and Config.Keys.q or Config.Keys.fish
                        if IsControlJustPressed(0, otherControl) then
                            wrongKey = true
                            break
                        end
                        if IsControlJustPressed(0, Config.Keys.cancel) then
                            break
                        end
                        Wait(0)
                    end

                    if success then
                        SendNUIMessage({ action = "catchSuccess" })
                        TriggerServerEvent('qb-fishing:server:catchFish', fish)
                        QBCore.Functions.Notify('شدّيت السمكة ' .. fish.name .. ' بنجاح!', 'success')
                        TaskPlayAnim(ped, 'amb@world_human_stand_fishing@idle_a', 'idle_a', 1.0, -1.0, 1500, 0, 0, false, false, false)
                        Wait(1200)
                    else
                        SendNUIMessage({ action = "fishEscaped" })
                        if wrongKey then
                            QBCore.Functions.Notify('غلطتي ف الحرف! السمكة هربت!', 'error')
                        else
                            QBCore.Functions.Notify('تأخرت! السمكة هربت!', 'error')
                        end
                        Wait(1200)
                    end
                    StopFishing()
                end
                break
            end
            Wait(80)
        end
    end)
end

function StopFishing()
    isFishing = false
    EnablePlayerFiring(PlayerId(), true)

    if inventoryBlocked then
        SetFishingInventoryBlocked(false)
    end

    local ped = PlayerPedId()
    ClearPedTasksImmediately(ped)
    ClearPedSecondaryTask(ped)

    -- حذف فوري + إعادة بعد فريمات
    DeleteRod()

    CreateThread(function()
        Wait(0)
        DeleteRod()
        Wait(50)
        DeleteRod()
        Wait(100)
        DeleteRod()
        Wait(200)
        DeleteRod()
    end)

    SendNUIMessage({ action = "stopFishing", stillInZone = inZone })
end

function GetRandomFish()
    local total = 0
    for _, f in pairs(Config.Fish) do
        total = total + f.chance
    end
    local rand = math.random(1, total)
    local current = 0
    for _, f in pairs(Config.Fish) do
        current = current + f.chance
        if rand <= current then
            return f
        end
    end
    return Config.Fish[1]
end

AddEventHandler('QBCore:Client:OnPlayerUnload', function()
    StopFishing()
end)

AddEventHandler('onResourceStop', function(res)
    if res == GetCurrentResourceName() then
        StopFishing()
        for _, blip in pairs(fishingBlips) do
            RemoveBlip(blip)
        end
    end
end)
