Config = {}

Config.Debug = false

-- العناصر المطلوبة (صنارة + طعم فقط)
Config.Items = {
    rod  = 'fishingrod',      -- الصنارة
    bait = 'fishbait'         -- الطعم
}

-- مدة الصيد (ثواني)
Config.MinWait = 8
Config.MaxWait = 22

-- احتمال هروب السمكة قبل ما تعض (0.0 - 1.0)
Config.EscapeChance = 0.0

-- الوقت اللي عندك بعد ما تضرب السمكة باش تضغط الحرف الصحيح (بالملي ثانية)
Config.BiteTime = 5000

-- ========================
-- نظام الماء الواقعي
-- ========================
Config.WaterDistance = 2.0
Config.WaterCheckSteps = 16
Config.MaxWaterHeightDifference = 3.0

-- أنواع الأسماك
Config.Fish = {
    { name = "sardine",         item = "sardine",      price = 35,    chance = 35, minWeight = 0.2, maxWeight = 0.6 },
    { name = "salmon",          item = "salmon",       price = 85,    chance = 22, minWeight = 1.5, maxWeight = 4.0 },
    { name = "tuna",            item = "tuna",         price = 140,   chance = 12, minWeight = 3.0, maxWeight = 8.0 },
    { name = "bass",            item = "bass",         price = 65,    chance = 18, minWeight = 1.0, maxWeight = 3.5 },
    { name = "rare_fish",       item = "rare_fish",    price = 450,   chance = 3,  minWeight = 5.0, maxWeight = 12.0 },
    { name = "shark_small",     item = "shark_small",  price = 10000, chance = 5,  minWeight = 15.0, maxWeight = 25.0 },
}

-- مفاتيح
-- E = 38 | Q = 44 | X = 73
Config.Keys = {
    fish   = 38,  -- E
    cancel = 73,  -- X
    q      = 44,  -- Q
}
