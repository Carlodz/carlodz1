local QBCore = exports['qb-core']:GetCoreObject()

-- تتبع اللاعبين اللي كيصيدو باش نمنع الـexploit
local fishingPlayers = {}

QBCore.Functions.CreateCallback('qb-fishing:server:hasItems', function(source, cb)
    local Player = QBCore.Functions.GetPlayer(source)
    if not Player then return cb({rod = false, bait = false}) end

    cb({
        rod  = Player.Functions.GetItemByName(Config.Items.rod)  ~= nil,
        bait = Player.Functions.GetItemByName(Config.Items.bait) ~= nil
    })
end)

RegisterNetEvent('qb-fishing:server:removeBait', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    local bait = Player.Functions.GetItemByName(Config.Items.bait)
    if not bait then return end

    Player.Functions.RemoveItem(Config.Items.bait, 1)
    TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items[Config.Items.bait], 'remove')
    fishingPlayers[src] = true
end)

RegisterNetEvent('qb-fishing:server:catchFish', function(fish)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end

    -- لازم يكون بدأ الصيد و طلع الطعم
    if not fishingPlayers[src] then return end
    fishingPlayers[src] = nil

    -- تحقق من أن السمكة موجودة فـ Config
    local valid = false
    local fishData = nil
    for _, f in pairs(Config.Fish) do
        if f.item == fish.item and f.name == fish.name then
            valid = true
            fishData = f
            break
        end
    end
    if not valid or not fishData then return end

    local weight = math.random(math.floor(fishData.minWeight * 10), math.floor(fishData.maxWeight * 10)) / 10
    Player.Functions.AddItem(fishData.item, 1)
    TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items[fishData.item], 'add')
    TriggerClientEvent('QBCore:Notify', src, 'حصلت على ' .. fishData.name .. ' (وزن: ' .. weight .. ' كغ)', 'success')
end)

AddEventHandler('playerDropped', function()
    local src = source
    fishingPlayers[src] = nil
end)
