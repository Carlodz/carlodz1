const promptUI      = document.getElementById('prompt-ui');
const biteUI        = document.getElementById('bite-ui');
const keyCircle     = document.getElementById('key-circle');
const requiredKeyEl = document.getElementById('required-key');
const biteLabel     = document.getElementById('bite-label');

let lastX = 0.5;
let lastY = 0.5;
let timer = null;

function showUI(el) {
    if (!el) return;
    el.classList.remove('hidden', 'hide-anim');
    void el.offsetWidth;
    el.classList.add('show');
    el.style.left = (lastX * 100) + '%';
    el.style.top  = (lastY * 100) + '%';
}

function hideUI(el, cb) {
    if (!el || el.classList.contains('hidden')) {
        if (cb) cb();
        return;
    }
    el.classList.remove('show');
    el.classList.add('hide-anim');
    setTimeout(function () {
        el.classList.add('hidden');
        el.classList.remove('hide-anim');
        if (cb) cb();
    }, 220);
}

function applyPos(x, y, onScreen) {
    lastX = x;
    lastY = y;
    [promptUI, biteUI].forEach(function (el) {
        if (!el || el.classList.contains('hidden')) return;
        if (onScreen) {
            el.style.left = (x * 100) + '%';
            el.style.top  = (y * 100) + '%';
            el.style.visibility = 'visible';
        } else {
            el.style.visibility = 'hidden';
        }
    });
}

window.addEventListener('message', function (event) {
    var data = event.data;

    if (data.action === 'enterZone') {
        showUI(promptUI);
        hideUI(biteUI);
    }

    if (data.action === 'leaveZone') {
        hideUI(promptUI);
        hideUI(biteUI);
    }

    if (data.action === 'startFishing') {
        // نخفي الـprompt، ما كنبينوش UI ديال السمكة
        hideUI(promptUI);
        hideUI(biteUI);
        clearTimeout(timer);
    }

    if (data.action === 'updatePos') {
        applyPos(data.x || 0.5, data.y || 0.5, data.onScreen);
    }

    // progress ما عادش محتاجينو (ما كاينش UI سمك)
    if (data.action === 'updateProgress') {
        // ignore
    }

    if (data.action === 'fishBite') {
        clearTimeout(timer);
        var key = (data.key || 'E').toUpperCase();
        if (requiredKeyEl) requiredKeyEl.textContent = key;
        if (keyCircle) {
            keyCircle.classList.remove('red');
            keyCircle.classList.add('white');
        }
        if (biteLabel) biteLabel.textContent = 'اضغط ' + key;

        hideUI(promptUI);
        showUI(biteUI);

        const biteTime = Number(data.time || 5000);
        const started = Date.now();
        const tick = function () {
            const left = Math.max(0, biteTime - (Date.now() - started));
            if (left <= 0) return;
            if (biteLabel) biteLabel.textContent = 'اضغط ' + key + '  ' + (left / 1000).toFixed(1) + 's';
            timer = setTimeout(tick, 100);
        };
        tick();
    }

    if (data.action === 'fishEscaped') {
        clearTimeout(timer);
        if (requiredKeyEl) requiredKeyEl.textContent = '!';
        if (keyCircle) {
            keyCircle.classList.remove('white');
            keyCircle.classList.add('red');
        }
        if (biteLabel) biteLabel.textContent = 'هربات!';
        hideUI(promptUI);
        showUI(biteUI);
    }

    if (data.action === 'catchSuccess') {
        clearTimeout(timer);
        if (keyCircle) {
            keyCircle.classList.remove('red');
            keyCircle.classList.add('white');
        }
        if (biteLabel) biteLabel.textContent = 'شدّيتها!';
        showUI(biteUI);
    }

    if (data.action === 'stopFishing') {
        clearTimeout(timer);
        hideUI(biteUI, function () {
            if (data.stillInZone) showUI(promptUI);
        });
    }
});
